package com.abc.BookDetails.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.abc.BookDetails.entity.Book;

import jakarta.persistence.Id;

@Repository
public interface BookDtlsRepository extends CrudRepository<Book,Integer>{
	
	
	     
	}


