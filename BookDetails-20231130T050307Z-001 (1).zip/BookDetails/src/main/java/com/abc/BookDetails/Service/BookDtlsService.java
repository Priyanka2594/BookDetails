package com.abc.BookDetails.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.BookDetails.Repository.BookDtlsRepository;
import com.abc.BookDetails.entity.Book;

import jakarta.persistence.Id;

@Service
public class BookDtlsService {
	
	@Autowired  
	BookDtlsRepository bookDtlsRepository;  
	//getting all books record by using the method findaAll() of CrudRepository  
	public List<Book> getAllBooks()   
	{  
	List<Book> books = new ArrayList<Book>();  
	bookDtlsRepository.findAll().forEach(books1 -> books.add(books1));  
	return books;  
	}  
	//getting a specific record by using the method findById() of CrudRepository  
	public Book getBooksById(int id)   
	{  
	return bookDtlsRepository.findById(id).get();  
	}  
	//saving a specific record by using the method save() of CrudRepository  
	public void saveOrUpdate(Book book)   
	{  
	bookDtlsRepository.save(book);  
	}  
	//deleting a specific record by using the method deleteById() of CrudRepository  
	public void delete(int id)   
	{  
	bookDtlsRepository.deleteById(id);  
	}  
	//updating a record  
	public void update(Book book, int id)   
	{  
	bookDtlsRepository.save(book);  
	}  

}
